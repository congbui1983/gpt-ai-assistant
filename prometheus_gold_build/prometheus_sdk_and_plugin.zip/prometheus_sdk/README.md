# PROMETHEUS SYSTEM SDK

Gọi hành động từ GPT bằng API Prometheus:

## Cấu hình
Tạo file `.env`:
```
PROMETHEUS_API_KEY=PROMETHEUS_SUPER_2025
PROMETHEUS_API_URL=https://eo9j512elidagoye.m.pipedream.net/agent-action
```

## Dùng SDK
```python
from prometheus_sdk import call_prometheus

payload = {
  "action_type": "log_to_sheet",
  "intent_description": "Ghi dữ liệu bài giảng",
  ...
}

response = call_prometheus(payload)
```