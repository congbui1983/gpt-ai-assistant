import requests
import os

def call_prometheus(payload):
    url = os.getenv("PROMETHEUS_API_URL")
    headers = {"X-API-Key": os.getenv("PROMETHEUS_API_KEY")}
    response = requests.post(url, json=payload, headers=headers)
    return response.json()
