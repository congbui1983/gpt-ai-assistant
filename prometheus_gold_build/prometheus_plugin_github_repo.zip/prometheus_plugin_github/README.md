# Prometheus System GPT Plugin

This repository hosts the Prometheus System plugin for GPT. It allows GPT-based agents to send files, log data to Google Sheets, and integrate with Notion, Telegram, and Webhooks.

## Features

- Secure API using API Key authentication
- Unified endpoint: `/agent-action`
- Supports logging, file upload, integrations
- Compatible with GPT Builder, OpenAI Plugins, LangChain

## Files

- `ai-plugin.json`: Plugin metadata
- `openapi.yaml`: API schema
- `logo.png`: Plugin icon

## Deploy

1. Host this repository with GitHub Pages or any static hosting
2. Ensure `openapi.yaml` and `ai-plugin.json` are public URLs
3. Import plugin into GPT using the URL to `ai-plugin.json`

## License

MIT
